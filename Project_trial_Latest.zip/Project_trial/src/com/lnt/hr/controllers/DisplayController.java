package com.lnt.hr.controllers;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.entities.Login;
import com.lnt.hr.entities.Registration;
import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;
import com.lnt.hr.services.InstituteRegistrationService;
import com.lnt.hr.services.ScholarshipService;

@Controller("DisplayController")
public class DisplayController 
{
	@Resource
	private InstituteRegistrationService insServices;
	
	@Resource
	private ScholarshipService scholarshipServices;
	
	
	@RequestMapping("/InstituteHome")
	public String getInstituteHomePageSuccess()
	{
		return "InstituteHome";
	}
	
	//*************ministry login form*******************
	@RequestMapping("/minHome")
	public String getMinistryHomePage()
	{
		return "minLoginForm";
	}
	
	
	@RequestMapping("/showLoginForm")
	public ModelAndView showLoginForm() 
	{
		ModelAndView mv = new ModelAndView("loginForm");
		return mv;
	}
	
	//*********************institute list by ministry***********************
	@RequestMapping("/getInsList")
	public ModelAndView getInstituteList()
	{
		ModelAndView mv=null;

			List<InstituteRegistration> insList;
			try 
			{
				insList = insServices.getInsList();
				mv=new ModelAndView();
				mv.addObject("insList", insList);
				mv.setViewName("InstituteList");
			}
			catch (RegistrationException e) 
			{
				mv.setViewName("errorPage");
				return mv;
			}
			
		return mv;
	}
	
	//*********************institute details by ministry***********************
	@RequestMapping("/getInstList")
	public ModelAndView getInsDetails(@RequestParam("instituteCode") long code)
	{
		ModelAndView mv= new ModelAndView("InstituteDetails");
		InstituteRegistration insDetails=null;
		try
		{
			insDetails=insServices.getInsDetails(code);
			mv.addObject("instituteDetails", insDetails);
		}
		catch(RegistrationException e)
		{

			mv.setViewName("errorPage");
			return mv;
		}
		return mv;
	}
	
	
	
	
	@RequestMapping("/insHome")
	public String getInstituteLoginPage()
	{
		return "instituteLogin";
	}
	
	
	
	
	//********************************************institute student application list*********************
	@RequestMapping("/getStudentApplicationList")
	public ModelAndView getStudentApplicationList()
	{
		ModelAndView mv=null;

			List<Scholarship> studList;
			try 
			{
		//		System.out.println("first");
				studList = scholarshipServices.getStudList();
	//			System.out.println("second");
				mv=new ModelAndView();
				mv.addObject("studList", studList);
		//		System.out.println("testttttt1");
				mv.setViewName("StudentList");
		//		System.out.println("testttttt         2111");
			}
			catch (ScholarshipException e) 
			{

				mv.setViewName("errorPage");
				return mv;
			}
			//System.out.println("asklfhdkh");
		return mv;
	}
	
	//****************student application details by ministry and institute***************
	@RequestMapping("/getApplicationDetails")		
	public ModelAndView getScholarshipApplicationDetails(@RequestParam("applicationId") int applicationId)
	{
		ModelAndView mv= new ModelAndView("StudentDetails");
		Scholarship applDetails=null;
		try
		{
			applDetails=scholarshipServices.getApplDetails(applicationId);
			mv.addObject("scholarshipDetails", applDetails);
		}
		catch(ScholarshipException e)
		{

			mv.setViewName("errorPage");
			return mv;
		}
		return mv;
	}
	
	//*********************Ministry Student List*****************************
	@RequestMapping("/getStuApplList")
	public ModelAndView getMinistryStudentApplicationList()
	{
		ModelAndView mv=null;

			List<Scholarship> studList;
			try 
			{
		//		System.out.println("first");
				studList = scholarshipServices.getMinStudList();
	//			System.out.println("second");
				mv=new ModelAndView();
				mv.addObject("studMinList", studList);
		//		System.out.println("testttttt1");
				mv.setViewName("ministryStudentList");
		//		System.out.println("testttttt         2111");
			}
			catch (ScholarshipException e) 
			{

				mv.setViewName("errorPage");
				return mv;
			}
			//System.out.println("asklfhdkh");
		return mv;
	}

}
