package com.lnt.hr.eligibility;

import com.lnt.hr.entities.Registration;
import com.lnt.hr.entities.Scholarship;

public interface CheckPragatiEligibility 
{
	public String CheckPragatiEligibility(Registration registration , Scholarship scholarship);

}
