package com.lnt.hr.eligibility;

import org.springframework.stereotype.Service;

import com.lnt.hr.entities.Registration;
import com.lnt.hr.entities.Scholarship;

@Service("Pragati")
public class Pragati implements CheckPragatiEligibility
{
	@Override
	public String CheckPragatiEligibility(Registration registration, Scholarship scholarship) 
	{
		String maritalStaus = scholarship.getMaritalStatus();
		long familyAnnualIncome = scholarship.getFamilyAnnualIncome();
		String gender = registration.getGender();

		if( gender.equals("Female") && maritalStaus.equals("Married") && (familyAnnualIncome<700000))
		{
			return "true";

		}
		else 
		{
			return "false";
		}

	}
}
