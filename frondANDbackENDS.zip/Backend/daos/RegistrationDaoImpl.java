package com.lnt.hr.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.Registration;
import com.lnt.hr.exception.LoginException;
import com.lnt.hr.exception.RegistrationException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class RegistrationDaoImpl implements RegistrationDao 
{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Registration insertNewStudent(Registration registration) throws RegistrationException 
	{
		try
		{
			entityManager.persist(registration);
			return registration;			
		}
		catch(Exception e)
		{
			throw new RegistrationException("OOP's!!! Something went wrong while inserting a new student", e);
		}

	}
}

