package com.lnt.hr.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;


@NamedQueries( { @NamedQuery(name="allInstitute",query="from InstituteRegistration")


})
@Entity
@Table(name="INSTITUTEREGISTRATION")
public class InstituteRegistration 
{
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "IDINSTITUTE_SEQ")
	@SequenceGenerator(name = "IDINSTITUTE_SEQ", sequenceName = "seq_institute", allocationSize = 1)
	@Id
	@Column(name="INSTITUTECODE")
	private long instituteCode;
	
	@Column(name="INSTITUTECATEGORY")
	private String instituteCategory;
	
	@Column(name="INSTITUTENAME")
	private String instituteName;
	
	@Column(name="STATE")
	private String state;
	
	@Column(name="DISTRICT")
	private String district;
	
		
	@Column(name="LOCATION")
	private String location;
	
	@Column(name="TYPE")
	private String type;
	
	@Column(name="AFF")
	private String aff;
	
	@Column(name="AFFUNIID")
	private int affUniId ; 
	
	@Column(name="YEARFROMADMISSIONSTARTED")
	private Date yearFromAdmissionStarted;
	
	@Column(name = "PASSWORD")
	private String password;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="PRINCIPALNAME")
	private String principalName;
	
	@Column(name="PRINCIPALMOBILENUMBER")
	private long principalMobileNumber;

	public InstituteRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InstituteRegistration(long instituteCode, String instituteCategory, String instituteName, String state,
			String district, String location, String type, String aff, int affUniId, Date yearFromAdmissionStarted,
			String password, String address, String principalName, long principalMobileNumber) {
		super();
		this.instituteCode = instituteCode;
		this.instituteCategory = instituteCategory;
		this.instituteName = instituteName;
		this.state = state;
		this.district = district;
		this.location = location;
		this.type = type;
		this.aff = aff;
		this.affUniId = affUniId;
		this.yearFromAdmissionStarted = yearFromAdmissionStarted;
		this.password = password;
		this.address = address;
		this.principalName = principalName;
		this.principalMobileNumber = principalMobileNumber;
	}

	public long getInstituteCode() {
		return instituteCode;
	}

	public void setInstituteCode(long instituteCode) {
		this.instituteCode = instituteCode;
	}

	public String getInstituteCategory() {
		return instituteCategory;
	}

	public void setInstituteCategory(String instituteCategory) {
		this.instituteCategory = instituteCategory;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAff() {
		return aff;
	}

	public void setAff(String aff) {
		this.aff = aff;
	}

	public int getAffUniId() {
		return affUniId;
	}

	public void setAffUniId(int affUniId) {
		this.affUniId = affUniId;
	}

	public Date getYearFromAdmissionStarted() {
		return yearFromAdmissionStarted;
	}

	public void setYearFromAdmissionStarted(Date yearFromAdmissionStarted) {
		this.yearFromAdmissionStarted = yearFromAdmissionStarted;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public long getPrincipalMobileNumber() {
		return principalMobileNumber;
	}

	public void setPrincipalMobileNumber(long principalMobileNumber) {
		this.principalMobileNumber = principalMobileNumber;
	}

	@Override
	public String toString() {
		return "InstituteRegistration [instituteCode=" + instituteCode + ", instituteCategory=" + instituteCategory
				+ ", instituteName=" + instituteName + ", state=" + state + ", district=" + district + ", location="
				+ location + ", type=" + type + ", aff=" + aff + ", affUniId=" + affUniId
				+ ", yearFromAdmissionStarted=" + yearFromAdmissionStarted + ", password=" + password + ", address="
				+ address + ", principalName=" + principalName + ", principalMobileNumber=" + principalMobileNumber
				+ "]";
	}

	
	
	

}

