package com.lnt.hr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="LOGIN")
public class Login 
{
	@Id
	@Column(name="LOGINID")
	private int loginId;
	@Column(name="PASSWORD")
	private String password;
	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Login(int loginId, String password) {
		super();
		this.loginId = loginId;
		this.password = password;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [loginId=" + loginId + ", password=" + password + "]";
	}

		
	
	
	
	
}	