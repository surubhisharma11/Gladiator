package com.lti.project.daos;

import com.lti.project.entity.Registration;
import com.lti.project.exception.RegistrationException;

public interface RegistrationDao
{
	public Registration insertNewStudent(Registration registration) throws RegistrationException;

}
