package com.lti.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.project.daos.ScholarshipDao;
import com.lti.project.entity.Scholarship;
import com.lti.project.exception.ScholarshipException;

@Service("ScholarshipServiceImpl")
public class ScholarshipServiceImpl implements ScholarshipService
{
	@Autowired
	private ScholarshipDao dao;
	
	
	@Override
	public List<Scholarship> getStudList() throws ScholarshipException
	{
		return dao.getStudList();
	}

	@Override
	public List<Scholarship> getMinStudList() throws ScholarshipException 
	{
		return dao.getMinStudList();
	}

	@Override
	public Scholarship getApplDetails(long applicationId) throws ScholarshipException 
	{
		return dao.getApplDetails(applicationId);
	}

	@Override
	public Scholarship setApplicationStatus(Scholarship scholarship) throws ScholarshipException 
	{

		return dao.setApplicationStatus(scholarship);
	}

	@Override
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException 
	{
		return dao.insertNewScholarship(scholarship);
	}

}
