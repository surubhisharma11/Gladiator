package com.lti.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.project.daos.InstituteRegistrationDao;
import com.lti.project.entity.InstituteRegistration;
import com.lti.project.exception.RegistrationException;

@Service("InstituteRegistrationServiceImpl")
public class InstituteRegistrationServiceImpl implements InstituteRegistrationService

{

	@Autowired
	InstituteRegistrationDao dao;
	
	
	@Override
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration)
			throws RegistrationException 
	{
		return dao.insertNewInstitute(instituteRegistration);
	}

	@Override
	public List<InstituteRegistration> getInsList() throws RegistrationException 
	{
		
		return dao.getInsList();
	}

	@Override
	public InstituteRegistration getInsDetails(long instituteCode) throws RegistrationException 
	{
		return dao.getInsDetails(instituteCode);
	}

}
