package com.lti.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.project.daos.RegistrationDao;
import com.lti.project.entity.Registration;
import com.lti.project.exception.RegistrationException;

@Service("RegistrationServiceImpl")
public class RegistrationServiceImpl implements RegistrationService
{
	@Autowired
	RegistrationDao regDao;

	public Registration insertNewStudent(Registration registration) throws RegistrationException 
	{
		return regDao.insertNewStudent(registration);
	}
	
	
}
