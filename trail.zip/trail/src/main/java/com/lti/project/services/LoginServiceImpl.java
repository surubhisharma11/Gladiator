package com.lti.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.project.daos.LoginDao;
import com.lti.project.entity.Login;
import com.lti.project.exception.LoginException;

@Service("LoginServiceImpl")
public class LoginServiceImpl implements LoginService
{
	@Autowired
	LoginDao loginDao;

	@Override
	public Login insertNewStudent(Login login) throws LoginException 
	{
		return loginDao.insertNewStudent(login);
	}

	@Override
	public int loginCheck(Login login) throws LoginException 
	{
		return loginDao.loginCheck(login);
	}

}
