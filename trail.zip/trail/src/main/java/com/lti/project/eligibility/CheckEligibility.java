package com.lti.project.eligibility;

import com.lti.project.entity.Scholarship;

public interface CheckEligibility 
{
	public String checkEligibility(Scholarship scholarship);

	
}
