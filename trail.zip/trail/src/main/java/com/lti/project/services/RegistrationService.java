package com.lti.project.services;

import com.lti.project.entity.Registration;
import com.lti.project.exception.RegistrationException;

public interface RegistrationService 
{
	public Registration insertNewStudent(Registration registration) throws RegistrationException;
}
